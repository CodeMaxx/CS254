Team Name - Chaos Legion
Team Members - Shaan Vaidya(150050004), Kanak Agrawal(150050016), Abhishek Kumar(150050020), Akash Trehan(150050031)



Honor Code:

Shaan Vaidya
“The entire work submitted by the above group members have been done by them, and no part has been copied, or copied-and-modified-to-obfuscate,
except the code fragments given by the instructors. All work that has been referenced has been properly cited, and no cited work has been copied, or copied-and-modified-to-obfuscate.”

Kanak Agrawal
“The entire work submitted by the above group members have been done by them, and no part has been copied, or copied-and-modified-to-obfuscate,
except the code fragments given by the instructors. All work that has been referenced has been properly cited, and no cited work has been copied, or copied-and-modified-to-obfuscate.”

Abhishek Kumar
“The entire work submitted by the above group members have been done by them, and no part has been copied, or copied-and-modified-to-obfuscate,
except the code fragments given by the instructors. All work that has been referenced has been properly cited, and no cited work has been copied, or copied-and-modified-to-obfuscate.”

Akash Trehan
“The entire work submitted by the above group members have been done by them, and no part has been copied, or copied-and-modified-to-obfuscate,
except the code fragments given by the instructors. All work that has been referenced has been properly cited, and no cited work has been copied, or copied-and-modified-to-obfuscate.”



Citation: http://stackoverflow.com/questions/20212714/reading-a-csv-file-into-struct-array




On doing make depend, in our code ATM.out is not created but an executable named flcli is created which is inside lin.x64/rel.

To execute, this make sure that you execute from the current directry itself, because .csv file is in the current directory.

Commands:
	make depend
	make
	lin.x64/rel/flcli
